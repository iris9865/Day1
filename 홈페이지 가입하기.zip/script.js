let isStarted = false;
const target = document.querySelector("#target");
const button = document.querySelector("button");

button.addEventListener("click", (e) =>{
  e.preventDefault();

  if(isStarted === false) {
    //카운터가 작동 중일 때
    isStarted = true;
    const token = String(Math.floor(Math.random()*1000000)).padStart(6, "0");
    target.innerText = token;
    target.style.color = "#" + token;
    
    let time = 180;

    setInterval(function() {
      if(time >= 0){
        let min = Math.floor(time / 60); //1초에 1번씩 = 3  2  1
        let sec = String(time % 60).padStart(2, "0"); //2자리 수 (padStart)
        document.querySelector("#timer").innerText = min + " : " + sec;
        time = time - 1;
      } else {
        document.querySelector("#finish").disabled = true
        isStarted = false;
        clearInterval(timer)
      }
    },1000)
    } else{
    //카운터가 작동 중일 때
    
  }
})


const changeFocus1 = () => {
  let phone1 = document.querySelector("#p1").value;
  if(phone1.length === 3 ) {
    document.querySelector("#p2").focus()
  }
}
const changeFocus2 = () => {
  let phone2 = document.querySelector("#p2").value;
  if(phone2.length === 4 ) {
    document.querySelector("#p3").focus()
  }
}
const changeFocus3 = () => {
  let p1 = document.querySelector("#p1").value;
  let p2 = document.querySelector("#p2").value;
  let p3 = document.querySelector("#p3").value;

  if(p1 && p2 && p3) {
    document.querySelector("button").disabled == false
  } else {
    document.querySelector("button").disabled == true
  }
}




// const check = function() {
//   let email = document.querySelector("#email").value;
//   let pw1 = document.querySelector("#pw1").value;
//   let pw2 = document.querySelector("#pw2").value;

//   if(email && pw1 && pw2) {
//     document.querySelector("#submit").disabled == false
//   } else {
//     document.querySelector("#submit").disabled == true
//   }
// }




