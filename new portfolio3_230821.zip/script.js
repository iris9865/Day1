// let locations = document.querySelectorAll(".location");
// const locations = document.querySelectorAll('.location');
const profileCard = document.getElementById('profile_card');
let modalWraps = document.querySelectorAll('.modalWrap');
let projectCloseBtns = document.querySelectorAll('.project_closeBtn');
const profileCloseBtn = document.getElementById('profile_closeBtn');
const clickBtn = document.querySelector('.click-me');
const github = document.querySelector('.github');
const tistory = document.querySelector('.tistory');
const kakaotalk = document.querySelector('.kakaotalk');
const project1 = document.querySelector('.umbrella');
const project2 = document.querySelector('.project2');

//프로젝트 클릭시, 각 아이콘과 모달 요소를 선택합니다.
let locations = document.querySelectorAll('.location');
let modals = document.querySelectorAll('.modal');
// console.log("modals:", modals)
// console.log("locations:", locations)


// 모달창 (프로젝트)
locations.forEach((location, index) => {
  location.addEventListener("click", () => {
    // modalWrap.classList.toggle("show");
    modalWraps.forEach(modal => modal.style.display = 'none');
    
    // 클릭한 아이콘에 해당하는 모달
    modalWraps[index].style.display = 'flex';
  });
});

// 모달창 닫기
projectCloseBtns.forEach((projectCloseBtn) => {
  projectCloseBtn.addEventListener("click", () => {
    modalWraps.forEach(modal => modal.style.display = 'none');
  });
});

// 모달창 (프로필)
clickBtn.addEventListener("click", () => {
  profileCard.classList.toggle("active");
});
profileCloseBtn.addEventListener("click", () => {
  profileCard.classList.toggle("active");
});


// 각 아이콘에 클릭 이벤트 리스너를 추가합니다.
// locations.forEach((location, index) => {
//   location.addEventListener('click', () => {
    // 모든 모달을 숨깁니다.
    // projectInners.forEach(projectInner => projectInner.style.display = 'none');
    
    // 클릭한 아이콘에 해당하는 모달을 표시합니다.
//     projectInners[index].style.display = 'flex';
//   });
// });



// 프로젝트.json 
// fetch('project.json')
// .then(response => response.json())
// .then(json => {
//   let output = "";
//   json.forEach(project => {
//     output += `
//       <h2>${project.id}</h2>
//       <ul>
//         <li>프로젝트명 : ${project.name}</li>
//         <li>프로젝트 설명 : ${project.desc}</li>
//       </ul>
//     `
//   });
//   document.querySelector(".project_details").innerHTML = output
// })
// .catch(error => console.log(error));


github.addEventListener("click", function() {
  window.open('https://github.com/iris9865');
});
tistory.addEventListener("click", function() {
  window.open('https://whoami-whereami.tistory.com');
});
kakaotalk.addEventListener("click", function() {
  window.open('https://open.kakao.com/o/s55cbSdf');
});
project1.addEventListener("click", function() {
  window.open('https://umbrella-d6f49.web.app/index.html');
});
project2.addEventListener("click", function() {
  window.open('https://voluble-palmier-d2cb96.netlify.app/');
});





