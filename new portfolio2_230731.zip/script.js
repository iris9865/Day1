//*FAQ 페이지 모달
const modal = document.getElementById('modalWrap');
const closeBtn = document.getElementById('closeBtn');

closeBtn.onclick = function() {
  modal.classList.toggle("show")
}
