import React from 'react'
import { Badge } from 'react-bootstrap'
import { useSelector } from 'react-redux'

const MoviesDetail = ({ item }) => {
  const {genreList} = useSelector((state) => state.movie)
  return (
    <div className='movieDetail'>
      {/* <div className='movieDetail_img' style={{backgroundImage: 'url('+`https://www.themoviedb.org/t/p/w600_and_h900_bestv2${item.poster_path}`+')'}}/> */}
      <div className='movieDetail_img' style={{backgroundImage: 'url('+`https://www.themoviedb.org/t/p/w600_and_h900_bestv2/zEqwfO5R2LrrLgV61xm8M9TmNTG`+')'}}/>
      <div className='movieDetail_desc'>
        <h1>title</h1>
        {/* <div>
          {item.genre_ids.map((id) => (
            <Badge bg='danger'>
              {genreList.find((item) => item.id === id).name}
            </Badge>
          ))}
        </div> */}
        <div>
          {/* <span>{item.vote_average}</span> */}
          <span>vote average</span> <br/>
          {/* <span>{item.adult ? "청불" : "Under 18"}</span> */}
          <span>청불여부</span>
          {/* <p>{item.overview}</p> */}
          <p>줄거리</p>
          <button className='go_to_video'>예고편 보러가기</button>
        </div>
      </div>
    </div>
  )
}

export default MoviesDetail
