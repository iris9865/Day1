import React from 'react'
import MoviesDetail from './MoviesDetail'
import { useDispatch } from 'react-redux'
import { movieAction } from '../redux/actions/MovieAction'
import { useEffect } from 'react'

const Movies = ({ movies }) => {
  const dispatch = useDispatch();
  useEffect(() => {
    dispatch(movieAction.getMovies());
  }, []);
  return (
    <div>
      {movies.results.map((item) => (
        <div>
          <MoviesDetail item={item}/>
        </div>
      ))}
    </div>
  )
}

export default Movies
