const inputBox = document.querySelector(".localStorage input");
const btnSave = document.querySelector(".btnSave");
const btnRead = document.querySelector(".btnRead");

btnSave.addEventListener("click", ()=> {
  const data = inputBox.value;
  localStorage.setItem("myKey", data);
  inputBox.value = "";
});

btnRead.addEventListener("click", ()=> {
  const data = localStorage.getItem("myKey");
  inputBox.value = data;
})


