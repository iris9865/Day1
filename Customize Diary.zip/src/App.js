import './App.css';
import { useRef, useState } from 'react';
import DiaryEditor from './Components/DiaryEditor';
import DiaryList from './Components/DiaryList';

function App() {
  const [data, setData] = useState([]);
  const dataID = useRef(1); 

  const onCreate = (author, emotion, content) => {
    const created_date = new Date().getTime();
    const newItem = {
      author,
      emotion,
      created_date,
      content,
      id: dataID.current
    };
    dataID.current += 1;
    setData([newItem , ...data]);
  }

  const onDelete = (targetID) => {
    const newDiaryList = data.filter((it) => it.id !== targetID);
    setData(newDiaryList);
  }

  const onEdit = (targetID, newContent) => {
    setData(
      data.map((it) => 
      it.id === targetID ? {...it, content: newContent} : it)
    )
  }
  
  return (
    <div className="App">
      <DiaryEditor onCreate={onCreate}/>
      <DiaryList diaryList={data} onDelete={onDelete} onEdit={onEdit}/>
    </div>
  );
}

export default App;
