import React from 'react'
import { useState , useRef } from 'react'

const DiaryEditor = ({onCreate}) => {
  const authorInput = useRef();
  const contentInput = useRef();
  const [state, setState] = useState({
    author: '',
    emotion: 1,
    content: ''
  });

  const handleChangeState = (e) => {
    setState({
      ...state, [e.target.name] : e.target.value})
    // setState(e.target.value);  
  }

  const handleSubmit = () => {
    if(state.author == '') {
      authorInput.current.focus();
      return;
    }
    if(state.content.length < 5) {
      contentInput.current.focus()
      return;
    } 

    onCreate(state.author, state.emotion, state.content)
    setState('')
  }
  

  return (
    <div className='DiaryEditor'>
      <h1>Today's Diary</h1>
      <div className='header'>
        <div className='author'>
          <span>작성자 :</span>
          <input name='author' value={state.author} ref={authorInput} onChange={handleChangeState} type='text'/>
        </div>
        <div>
          <span>오늘의 감정점수</span>
          <select name='emotion' value={state.emotion} onChange={handleChangeState}>
            <option value={1}>😄</option>
            <option value={2}>🙂</option>
            <option value={3}>😐</option>
            <option value={4}>🙁</option>
            <option value={5}>😠</option>
          </select>
        </div>
      </div>
      <div className='content'>
        <textarea name='content' value={state.content} ref={contentInput} onChange={handleChangeState}  placeholder='오늘의 일기를 작성해주세요!' ></textarea>
      </div>
      <div>
        <button onClick={handleSubmit}>일기 저장하기</button>
      </div>
    </div>
  )
}

export default DiaryEditor
