import React from 'react'
import DirayItem from './DirayItem'

const DiaryList = ({diaryList, onDelete, onEdit}) => {
  return (
    <div className='DiaryList'>
      <hr/>
      <h2>Diary List</h2>
      <h4>{diaryList.length}개의 일기가 있습니다</h4>
      <div> 
        {diaryList.map((it) => 
          <DirayItem key={it.id} {...it} onDelete={onDelete} onEdit={onEdit}/> 
        )}
      </div>
    </div>
  )
}

export default DiaryList
