let locations = document.querySelectorAll(".location");
const profileCard = document.getElementById('profile_card');
const modal = document.getElementById('modalWrap');
const projectCloseBtn = document.getElementById('project_closeBtn');
const profileCloseBtn = document.getElementById('profile_closeBtn');
const clickBtn = document.querySelector('.click-me');
const github = document.querySelector('.github');
const tistory = document.querySelector('.tistory');
const kakaotalk = document.querySelector('.kakaotalk');


// 모달창 (프로젝트)
locations.forEach((location) => {
  location.addEventListener("click", () => {
    modal.classList.toggle("show");
  });
});

projectCloseBtn.addEventListener("click", () => {
  modal.classList.toggle("show");
});

// 모달창 (프로필)
clickBtn.addEventListener("click", () => {
  profileCard.classList.toggle("active");
})
profileCloseBtn.addEventListener("click", () => {
  profileCard.classList.toggle("active");
})



// 프로젝트.json 
fetch('project.json')
.then(response => response.json())
.then(json => {
  let output = "";
  json.forEach(project => {
    output += `
      <h2>${project.id}</h2>
      <ul>
        <li>프로젝트명 : ${project.name}</li>
        <li>프로젝트 설명 : ${project.desc}</li>
      </ul>
    `
  });
  document.querySelector(".project_details").innerHTML = output
})
.catch(error => console.log(error));


github.addEventListener("click", function() {
  window.open('https://github.com/iris9865');
});
tistory.addEventListener("click", function() {
  window.open('https://whoami-whereami.tistory.com');
});
kakaotalk.addEventListener("click", function() {
  window.open('https://open.kakao.com/o/s55cbSdf');
});