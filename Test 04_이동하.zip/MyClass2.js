export let sentence2 = "항상 그렇듯 늘 파이팅입니다!"

// export function sentence2() {
//   console.log("항상 그렇듯 늘 파이팅입니다!");
// }