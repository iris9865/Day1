import { sentence1 } from "./MyClass1";
import { sentence2 } from "./MyClass2";

sentence1();
sentence2();