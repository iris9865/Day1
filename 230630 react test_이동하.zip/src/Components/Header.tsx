import React from 'react'
import './Header.css';

const Header = () => {
  return (
    <div>
      <h2>
        회원가입을 위해 <br />
        정보를 입력해주세요
        </h2>
    </div>
  )
}

export default Header
