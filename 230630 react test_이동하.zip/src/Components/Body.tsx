import React, { useState } from 'react'
import './Body.css';

const Body = () => {
  const [email, setEmail] = useState("");
  const [name, setName] = useState("");
  const [pw, setPw] = useState("");
  const [pwConfirm, setPwConfirm] = useState("");

  const handleChangeEmail = (e: any) => {
    setEmail(e.target.value);
  }
  const handleChangeName = (e: any) => {
    setName(e.target.value);
  }
  const handleChangePw = (e: any) => {
    setPw(e.target.value);
  }
  const handleChangePwConfirm = (e: any) => {
    setPwConfirm(e.target.value);
  }

  const [errorEmail, setErrorEmail] = useState("");
  const [errorName, setErrorName] = useState("");
  const [errorPw, setErrorPw] = useState("");
  const [errorPwConfirm, setErrorPwConfirm] = useState("");

  const handleClick = () => {
    if(email === "") {
      setErrorEmail("이메일을 입력해주세요");
    }
    if(name === "") {
      setErrorName("이름을 입력해주세요");
    }
    if(pw === "") {
      setErrorPw("비밀번호를 입력해주세요");
    }
    if(pwConfirm === "") {
      setErrorPwConfirm("비밀번호를 다시 입력해주세요");
    }
    if(email !== "" && name !== "" && pw !== "" && pwConfirm !=="") {
      alert("회원가입이 완료되었습니다!");
    }
  }

  return (
    <div>
      <div className='inputForm'>
        <label>*이메일</label>
        <input type="text" value={email} onChange={handleChangeEmail}/>
        <div style={{color: 'crimson'}}>{errorEmail}</div>
        <label>*이름</label>
        <input type="text" value={name} onChange={handleChangeName}/>
        <div style={{color: 'crimson'}}>{errorName}</div>
        <label>*비밀번호</label>
        <input type="password" value={pw} onChange={handleChangePw}/>
        <div style={{color: 'crimson'}}>{errorPw}</div>
        <label>*비밀번호 확인</label>
        <input type="password" value={pwConfirm} onChange={handleChangePwConfirm}/>
        <div style={{color: 'crimson'}}>{errorPwConfirm}</div>
      </div>
      <div className='gender'>
        <input type="radio" name='gender' />
        <label>여성</label>
        <input type="radio" name='gender' />
        <label>남성</label>
      </div>
      <div className='agreement'>
        <input type="checkbox" />
        <p>이용약관 개인정보 수집 및 이용에 모두 동의합니다.</p>
      </div>
      <hr />
      <button onClick={handleClick}>가입하기</button>
    </div>
    
  )
}

export default Body
