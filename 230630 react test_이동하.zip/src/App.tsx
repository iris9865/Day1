import React from 'react';
import logo from './logo.svg';
import './App.css';
import Header from './Components/Header';
import Body from './Components/Body';
import { useState } from 'react';

function App() {
  return (
    <div className="App">
      <div className='wrapper'>
        <Header/>
        <Body />
      </div>
    </div>
  );
}

export default App;
