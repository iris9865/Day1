import React from 'react'
import { useState,useContext } from 'react'
import { styled } from 'styled-components'
import TextInput from './TextInput'
import Button from './Button'
import Title from './Title'
import { TodoListContext } from './ToDoListContextProvider'
import {useNavigate} from 'react-router-dom'
import ShowInputButton from './ShowInputButton'

const Container = styled.div`
  position: absolute;
  top: 0;
  left: 0;
  bottom: 0;
  right: 0;
  display: flex;
  align-items: center;
  justify-content: center;
`;
// const Background = styled.div`
//   position: absolute;
//   top: 0;
//   left: 0;
//   bottom: 0;
//   right: 0;
//   background-color: rgb(0, 0, 0, 0.75);
// `;
const Contents = styled.div`
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center; 
  background-color: #fff;
  border-radius: 8px;
  padding: 32px;
`;
const InputContainer = styled.div`
  display: flex;
  align-itmes: center;
  justify-content: center;
`;

const ToDoInput = () => {
  const navigate = useNavigate();
  const  { onAdd } = useContext(TodoListContext); //부모로부터 값을 받는 대신 최상위 루트로부터 값을 받기
  const [toDo, setToDo] = useState("");
  const onAddTodo = () => {
    if(toDo === "") return;

    onAdd(toDo);
    setToDo('');
  }

  return (
    <Container>
      {/* <Background> */}
        <Contents>
          <Title label='할 일 추가' />
          <InputContainer>
            <TextInput value={toDo} onChange={setToDo}/>
            <Button label='추가' color='#304ffe' onClick={onAddTodo}/>
          </InputContainer>
        </Contents>
        <ShowInputButton show={true} onClick={() => navigate('/')}/>
      {/* </Background> */}
    </Container>
  )
}

export default ToDoInput
