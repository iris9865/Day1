import React from 'react';
import './App.css';
import { styled } from 'styled-components'
import { useState } from 'react';
import DataView from './Components/DataView';
import { ToDoListContextProvider } from './Components/ToDoListContextProvider';
import ToDoInput from './Components/ToDoInput';
import {Routes, Route} from 'react-router-dom';
import Header from './Components/Header';

const Container = styled.div`
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  height: 100vh;
  background-color: #eee;
`;

function App() {
  const [toDoList, setToDoList] = useState([
    '리액트 공부하기', 
    '운동하기', 
    '책 읽기'
  ]);
  // const [toDo, setToDo] = useState("");
  const [showToDoInput, setShowToDoInput] = useState(false);

  const onDelete = (toDo: string) => {
    setToDoList(toDoList.filter((item) => item !== toDo));
  };

  const onAdd = (toDo: string) => {
    if(toDo === "") return;

    setToDoList([...toDoList, toDo]);
    // setToDo("");
  }

  return (
    <Container>
      <ToDoListContextProvider>
        <Header />
        <Routes>
          <Route path='/'
          element={<DataView />}/>
          <Route path='/add' element={<ToDoInput />}/>
        <Route path='*'
        element = {
          <>
            404
            <br/>
            Not Found
          </>
        }
        />
        </Routes>
      </ToDoListContextProvider>
    </Container>
  );
}

export default App;
