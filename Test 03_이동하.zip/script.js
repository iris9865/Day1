const inputBox = document.querySelector(".localStorage input");
const btnSave = document.querySelector(".btnSave");
const btnRemove = document.querySelector(".btnRemove");
const btnClear = document.querySelector(".btnClear");

btnSave.addEventListener('click', () => {
  const data = inputBox.value;
  localStorage.setItem('myKey', data);
  inputBox.value = "";
});

btnRemove.addEventListener('click', () => {
  localStorage.removeItem('myKey');
});

btnClear.addEventListener('click', () => {
  localStorage.clear();
});