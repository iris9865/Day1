import React from 'react'
import { createContext, useState } from 'react'

interface Context {
  readonly toDoList: string[];
  readonly onAdd : (toDo: string) => void;
  readonly onDelete: (toDo: string) => void;
}

const TodoListContext = createContext<Context>({
  toDoList: [],
  onAdd: (): void => {},
  onDelete: (): void => {} 
});

interface Props {
  children: JSX.Element | JSX.Element[];  //JSX파일포맷이거나 파일포맷 배열이거나
}

const ToDoListContextProvider = ({children}: Props) => {
  const [toDoList, setToDoList] = useState([
    "리액트 공부하기",
    "운동하기",
    "책 읽기"
  ]);
  const onAdd = (toDo: string) => {
    if(toDo === "") return;
    setToDoList([...toDoList, toDo]);
  }
  const onDelete = (toDo: string) => {
    setToDoList(toDoList.filter((item) => item !== toDo));
  };
  
  return (
    <TodoListContext.Provider value={{toDoList, onAdd, onDelete}}>
      {children}
    </TodoListContext.Provider>
  )
}

export {ToDoListContextProvider, TodoListContext}; 
