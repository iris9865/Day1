import React from 'react'
import { styled } from 'styled-components'
import TodoItem from './TodoItem'
// import { useContext } from 'react';
// import { TodoListContext } from './ToDoListContextProvider';

const Container = styled.div`
  display: flex;
  flex-direction: column;
`;

// interface Props {
//   readonly toDoList: ReadonlyArray<string>;
//   readonly onDelete?: (toDo: string) => void;
// }

const TodoList = () => {
  const {toDoList, onDelete} = useContext(TodoListContext); //구조분해할당으로 값을 받아옴
  return (
    <Container>
      {toDoList.map((toDo) => (
        <TodoItem
        key={toDo} //리액트 특정상 리렌더링 되어지는데 리렌더링 되고 나서 리스트들이 자기의 값을 찾을 때 필요한 키값
        label={toDo} 
        onDelete={() => {
          if (typeof onDelete === 'function') onDelete(toDo);
        }}/>
      ))}
    </Container>
  )
}

export default TodoList
