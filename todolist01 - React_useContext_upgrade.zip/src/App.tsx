import React from 'react';
import './App.css';
import { styled } from 'styled-components'
import { useState } from 'react';
import Title from './Components/Title';
import Button from './Components/Button';
import TodoItem from './Components/TodoItem';
import TodoList from './Components/TodoList';
import DataView from './Components/DataView';
import TextInput from './Components/TextInput';
import ToDoInput from './Components/ToDoInput';
import ShowInputButton from './Components/ShowInputButton';
import InputContainer from './Components/InputContainer';
import { ToDoListContextProvider } from './Components/ToDoListContextProvider'; //기본값이 아니라 두 가지 중 하나(ToDoListCntexProvider 파일 마지막 줄)

const Container = styled.div`
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  height: 100vh;
  background-color: #eee;
`;

function App() {
  const [toDoList, setToDoList] = useState([
    '리액트 공부하기', 
    '운동하기', 
    '책 읽기'
  ]);
  // const [toDo, setToDo] = useState("");
  const [showToDoInput, setShowToDoInput] = useState(false);

  const onDelete = (toDo: string) => {
    setToDoList(toDoList.filter((item) => item !== toDo));
  };

  const onAdd = (toDo: string) => {
    if(toDo === "") return;

    setToDoList([...toDoList, toDo]);
    // setToDo("");
  }

  return (
    <Container>
      <ToDoListContextProvider>
        <DataView />
        <InputContainer />
      </ToDoListContextProvider>
    </Container>
  );
}

export default App;
