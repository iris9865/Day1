let locations = document.querySelectorAll(".location");
const modal = document.getElementById('modalWrap');
const closeBtn = document.getElementById('closeBtn');
const clickBtn = document.querySelector('.click-me');

// 모달창 
locations.forEach((location) => {
  location.addEventListener("click", () => {
    modal.classList.toggle("show");
  });
});

closeBtn.addEventListener("click", () => {
  modal.classList.toggle("show");
})

// 프로젝트.json 
fetch('project.json')
.then(response => response.json())
.then(json => {
  let output = "";
  json.forEach(project => {
    output += `
      <h2>${project.id}</h2>
      <ul>
        <li>프로젝트명 : ${project.name}</li>
        <li>프로젝트 설명 : ${project.desc}</li>
      </ul>
    `
  });
  document.querySelector(".project_details").innerHTML = output
})
.catch(error => console.log(error));