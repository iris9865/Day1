const btn = document.querySelector("button");
const url = "https://jsonplaceholder.typicode.com/comments"


btn.addEventListener("click", ()=> {
  fetch(url)
  .then(response => response.json())
  .then(data => {
    const log = document.querySelector("#log");
    log.innerHTML = data;
  })
})