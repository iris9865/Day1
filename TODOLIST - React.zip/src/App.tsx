import React, { useRef, useState } from 'react';
import logo from './logo.svg';
import './App.css';
import Header from './Component/Header';
import TodoEditor from './Component/TodoEditor';
import TodoList from './Component/Todolist';

const mockTodo = [
  {
    id : 0,
    isDone : false,
    content : "공부하기",
    createDate : new Date().getTime()
  },
  {
    id : 1,
    isDone : false,
    content : "빨래하기",
    createDate : new Date().getTime()
  },
  {
    id : 2,
    isDone : false,
    content : "노래하기",
    createDate : new Date().getTime()
  }
]

function App() {
  const [todo, setTodo] = useState(mockTodo);
  const idRef = useRef(3)  //useRef는 안에 들어오는 인자값을 객체로 만들어줌
  const onCreate = (content: any) => {
    const newItem = {
      id : idRef.current,
      content,
      isDone: false,
      createDate: new Date().getTime()
    };
    setTodo([newItem, ...todo]);   //... : 앞전의 값들도 하나씩 넣음
    idRef.current += 1;  //새로 들어온 애들은 3부터 하나씩 늘어난다
  };
  const onUpdate = (targetId: any) => {
    setTodo(todo.map(
      (it) => {
        if(it.id === targetId) {
          return {
            ...it,
            isDone : !it.isDone,
          };
        } else {
          return it;
        }
      }
    ))
  }

  return (
    <div className='App'>
      <Header />
      <TodoEditor onCreate={onCreate}/>
      <TodoList todo={todo} onUpdate={onUpdate}/>
    </div>
  );
}

export default App;
