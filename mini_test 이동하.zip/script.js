//전화번호 입력칸 자동이동
const changeFocus1 = () =>{
  let phone1 = document.querySelector("#p1").value;
  if(phone1.length === 3) {
    document.querySelector("#p2").focus()
  }
}
const changeFocus2 = () =>{
  let phone2 = document.querySelector("#p2").value;
  if(phone2.length === 4) {
    document.querySelector("#p3").focus()
  }
}
const changeFocus3 = () =>{
  let p1 = document.querySelector("#p1").value;
  let p2 = document.querySelector("#p2").value;
  let p3 = document.querySelector("#p3").value;

  if(p1 && p2 && p3) {
    document.querySelector("#send").disabled == false
  } else {
    document.querySelector("#send").disabled == true
  }
}

//인증번호 전송
let isStarted = false;
const target = document.querySelector("#target");
const sendButton = document.querySelector("#send");

sendButton.addEventListener("click", (e) =>{
  e.preventDefault();

  if(isStarted === false) {
    //카운터가 작동 중일 때
    isStarted = true;
    const token = String(Math.floor(Math.random()*1000000)).padStart(6, "0");
    target.innerText = token;
    target.style.color = "#" + token;
    
    let time = 180;

    setInterval(function() {
      if(time >= 0){
        let min = Math.floor(time / 60); //1초에 1번씩 = 3  2  1
        let sec = String(time % 60).padStart(2, "0"); //2자리 수 (padStart)
        document.querySelector("#timer").innerText = min + " : " + sec;
        time = time - 1;
      } else {
        document.querySelector("#finish").disabled = true
        isStarted = false;
        clearInterval(timer)
      }
    },1000)
    } else{
  }
})