// ===ScrollTo Event===
$(function(){
  $('header a').click(function(e){
    $.scrollTo(this.hash || 0, 1000);
    e.preventDefault();
  });
});

// === homepage === 
$(".click-me").click(() => {
  $(".right-content").toggle(1000);
})
$(".close").click(() => {
  $(".right-content").hide(1000);
})





// === project page ===
$('.project-photo').slick({
  dots: true,
  infinite: true,
  speed: 500,
  fade: true,
  autoplay: true,
  autoplaySpeed: 2000,
  cssEase: 'linear'
});






// ==contact page==
const contactBtn = document.querySelector(".btn-contact")
const btns = document.querySelector(".contact-btns");

contactBtn.addEventListener("click", () => {
  btns.classList.toggle("active");
})

// $(".btn-contact").click(() => {
//   $(".contact-btns").toggle("active", 1000);
// })

const instaBtn = document.querySelector(".btn-insta");
const modalBox = document.querySelector("#modal-box");
const instaClose = document.querySelector("#close");

instaBtn.addEventListener("click", () =>{
  modalBox.style.display = 'flex';
});

instaClose.addEventListener("click", ()=>{
  modalBox.style.display = 'none';
})

