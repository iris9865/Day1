function getProduct(searchQuery) {
  return async (dispatch, getState) => {
    let url = `https://my-json-server.typicode.com/iris9865/React-shoppingmall/products?q=${searchQuery}`;
        console.log(url)
        let response = await fetch(url); 
        let data = await response.json();
        dispatch({type: "GET_PRODUCT_SUCCESS", payload: {data}});
        // setProductList(data);
  }
}

export const productAction = {getProduct};