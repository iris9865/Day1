import { createStore , applyMiddleware } from "redux";
import thunk from "redux-thunk";
import productReducer from "./reducers/productReducer";
import rootReducer from "./reducers" //reducers폴다 안에 대표인 index.js를 rootReducer로 불러오겠다
import { composeWithDevTools } from "redux-devtools-extension";

let store = createStore(
  rootReducer, 
  composeWithDevTools(applyMiddleware(thunk)));

export default store;