import React from 'react'
import './Editor.css'
import { useState, useEffect } from 'react'
import { getFormattedDate, emotionList } from '../Util'
import Button from './Button'
import { useNavigate } from 'react-router-dom'
import EmotionItem from './EmotionItem'

const Editor = ({ initData, onSubmit }) => {

  const navigate = useNavigate();
  useEffect(() => {
    if (initData) {
      setState({
        ...initData, date: getFormattedDate(new Date(parseInt(initData.date)))
      })
    }
  },[initData])

  const [state, setState] = useState({
    date: getFormattedDate(new Date()),
    emotionId : 3,
    content:'',
  });

  const handleChangeDate = (e) => {
    setState({
      ...state, date: e.target.value
    });
  }

  const handleChangeContent = (e) => {
    setState({
      ...state, content: e.target.value
    })
  }

  const handleSubmit = () => {
    onSubmit(state)
  }

  const handleGoBack = () => {
    navigate(-1);
  }
  const handleChangeEmotion = (emotionId) => {
    setState({
      ...state, emotionId
    })
  }

  return (
    <div className='Editor'>
      <div className='editor_section'>
        <h4>오늘의 날짜</h4>
        <div className='input_wrapper'>
          <input type='date' value={state.date} onChange={handleChangeDate} />
        </div>
      </div>
      <div className='editor_section'>
        <h4>오늘의 감정</h4>
        <div className='input_wrapper emotion_list_wrapper'>
          {emotionList.map((it) => (
            // <img key={it.id} src={it.img} alt={`emotion${it.id}`} />
            <EmotionItem key={it.id} {...it} onClick={handleChangeEmotion} isSelected={state.emotionId === it.id} />
          ))}
        </div>
      </div>
      <div className='editor_section'>
        <h4>오늘의 일기</h4>
        <div className='input_wrapper'>
          <textarea value={state.content} onChange={handleChangeContent} placeholder='오늘은 어땠나요?'/>
        </div>
      </div>
      <div className='editor_section bottom_section'>
        <Button onClick={handleGoBack} text={"취소하기"} />
        <Button onClick={handleSubmit} text={"작성완료"} type={"positive"}/>
      </div>
    </div>
  )
}

export default Editor
