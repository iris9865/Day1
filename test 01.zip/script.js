setInterval(function(){
  const now = new Date();
  console.log(now);

  const hour = now.getHours();
  const min = now.getMinutes();
  const sec = now.getSeconds();

  const degHour = hour*(360/12) + min*(360/12/60);
  const degMin = min*(360/60);
  const degSec = sec*(360/60);

  const lineHour = document.querySelector(".lineHour");
  const lineMin = document.querySelector(".lineMin");
  const lineSec = document.querySelector(".lineSec");

  lineHour.style.transform = `rotate(${degHour}deg)`
  lineMin.style.transform = `rotate(${degMin}deg)`
  lineSec.style.transform = `rotate(${degSec}deg)`
}, 1000);
