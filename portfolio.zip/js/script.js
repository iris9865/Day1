$(function(){
  $('header a').click(function(e){
    $.scrollTo(this.hash || 0, 1000);
    e.preventDefault();
  });
});

let mainSlider = $('.main-slider');
let innerSlider = $('.inner-slider');

mainSlider.slick({
    slidesToShow: 1,
    dots: true,
});

innerSlider.slick({
    slidesToShow: 1,
})

mainSlider.on('wheel', function(e) {
  e.preventDefault();

  if (e.originalEvent.deltaY < 0) {
    $(this).slick('slickPrev');
  } else {
    $(this).slick('slickNext');
  }
});

innerSlider.on('wheel', function(e) {
  e.stopPropagation();
  e.preventDefault();

  if (e.originalEvent.deltaY < 0) {
    $(this).slick('slickPrev');
  } else {
    $(this).slick('slickNext');
  }
});

const open = document.querySelector(".click-me");
const homeContent = document.querySelector(".right-content");
const close = document.querySelector(".close");



// open.addEventListener("click", () => {
//   homeContent.classList.toggle("active");
// })