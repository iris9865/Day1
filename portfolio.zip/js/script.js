// ===ScrollTo Event===
$(function(){
  $('header a').click(function(e){
    $.scrollTo(this.hash || 0, 1000);
    e.preventDefault();
  });
});

// === homepage === 
$(".click-me").click(() => {
  $(".right-content").toggle(1000);
})
$(".close").click(() => {
  $(".right-content").hide(1000);
})

// let content = "Hi ! Good to see y’all I’m Iris Lee \n And I am front-end developer :) \n Do you want to see my portfolio? ";
// const text = document.querySelector(".text")
// let index = 0;
  
// function typing(){
//   text.textContent += content[index++]
//   if(index > content.length){
//     text.textContent = ""
//     index = 0;
//   }
// }
// setInterval(typing, 100)




const content = "Hi ! Good to see y’all ! I’m Iris Lee \n And I am front-end developer :) \n Do you want to see my portfolio? ";
const text = document.querySelector(".text");
let i = 0;

function typing(){
  if (i < content.length) {
    let txt = content.charAt(i);
    text.innerHTML += txt === "\n" ? "<br/>": txt;;
    i++;
  }
}
setInterval(typing, 100)



//스크롤 연동 fade-in fade-out , html section class="fade" 지명 
// $(window).on("load", function () {
//   function fade() {
//     let animation_height = $(window).innerHeight() * 0.5;
//     let ratio = Math.round((1 / animation_height) * 10000) / 10000;
//     $(".fade").each(function () {
//       let objectTop = $(this).offset().top;
//       let windowBottom = $(window).scrollTop() + $(window).innerHeight();
//       if (objectTop < windowBottom) {
//         if (objectTop < windowBottom - animation_height) {
//           $(this).css({
//             transition: "opacity 0.1s linear",
//             transition: "left 0.1s linear",
//             opacity: 1,
//             left: "0px",
//           });
//         } else {
//           $(this).css({
//             transition: "opacity 0.5s linear",
//             opacity: (windowBottom - objectTop) * ratio,
//             transition: "left 0.5s linear",
//             left: `${200 * (1 - (windowBottom - objectTop) * ratio)}px`,
//           });
//         }
//       } else {
//         $(this).css({
//           opacity: 0,
//           left: "200px",
//         });
//       }
//     });
//   }
//   $(".fade").css({
//     opacity: 0,
//     left: "200px",
//   });
//   fade();

//   $(window).scroll(function () {
//     fade();
//   });
// });


// === project page ===
$('.project-photo').slick({
  dots: true,
  infinite: true,
  speed: 500,
  fade: true,
  autoplay: true,
  autoplaySpeed: 2000,
  cssEase: 'linear'
});



// ==contact page==
const contactBtn = document.querySelector(".btn-contact")
const btns = document.querySelector(".contact-btns");

contactBtn.addEventListener("click", () => {
  btns.classList.toggle("active");
})

// $(".btn-contact").click(() => {
//   $(".contact-btns").toggle("active", 1000);
// })

const instaBtn = document.querySelector(".btn-insta");
const modalBox = document.querySelector("#modal-box");
const instaClose = document.querySelector("#close");



instaBtn.addEventListener("click", () =>{
  modalBox.style.display = 'flex';
});

instaClose.addEventListener("click", ()=>{
  modalBox.style.display = 'none';
})

