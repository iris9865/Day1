// ===ScrollTo Event===
$(function(){
  $('header a').click(function(e){
    $.scrollTo(this.hash || 0, 1000);
    e.preventDefault();
  });
});

// === homepage === 
$(".click-me").click(() => {
  $(".right-content").toggle(1000);
})
$(".close").click(() => {
  $(".right-content").hide(1000);
})

// === project page ===
let mainSlider = $('.main-slider');
let innerSlider = $('.inner-slider');

mainSlider.slick({
    slidesToShow: 1,
    dots: true,
});

innerSlider.slick({
    slidesToShow: 1,
})

mainSlider.on('wheel', function(e) {
  e.preventDefault();

  if (e.originalEvent.deltaY < 0) {
    $(this).slick('slickPrev');
  } else {
    $(this).slick('slickNext');
  }
});

innerSlider.on('wheel', function(e) {
  e.stopPropagation();
  e.preventDefault();

  if (e.originalEvent.deltaY < 0) {
    $(this).slick('slickPrev');
  } else {
    $(this).slick('slickNext');
  }
});

// ==contact page==
const contactBtn = document.querySelector(".btn-contact")
const btns = document.querySelector(".contact-btns");

contactBtn.addEventListener("click", () => {
  btns.classList.toggle("active");
})

// $(".btn-contact").click(() => {
//   $(".contact-btns").toggle("active", 1000);
// })

const instaBtn = document.querySelector(".btn-insta");
const modalBox = document.querySelector("#modal-box");
const instaClose = document.querySelector("#close");

instaBtn.addEventListener("click", () =>{
  modalBox.style.display = 'flex';
});

instaClose.addEventListener("click", ()=>{
  modalBox.style.display = 'none';
})

