// ===ScrollTo Event===
$(function(){
  $('header a').click(function(e){
    $.scrollTo(this.hash || 0, 1000);
    e.preventDefault();
  });
});

// === homepage === 
$(".click-me").click(() => {
  $(".right-content").toggle(1000);
})
$(".close").click(() => {
  $(".right-content").hide(1000);
})

// === project page ===
let mainSlider = $('.main-slider');
let innerSlider = $('.inner-slider');

mainSlider.slick({
    slidesToShow: 1,
    dots: true,
});

innerSlider.slick({
    slidesToShow: 1,
})

mainSlider.on('wheel', function(e) {
  e.preventDefault();

  if (e.originalEvent.deltaY < 0) {
    $(this).slick('slickPrev');
  } else {
    $(this).slick('slickNext');
  }
});

innerSlider.on('wheel', function(e) {
  e.stopPropagation();
  e.preventDefault();

  if (e.originalEvent.deltaY < 0) {
    $(this).slick('slickPrev');
  } else {
    $(this).slick('slickNext');
  }
});

// ==contact page==
$(".btn-contact").click(() => {
  $(".contact-btns").toggle(1000);
})
