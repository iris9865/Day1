$(function() {
  $('.main_gnb').load('/include/navigation.html');
});

  // 회원가입 동의약관
  function signup() {
    const email = document.querySelector("#email").value;
    const name = document.querySelector("#name").value;
    const password = document.querySelector("#password").value;
    const passwordCheck = document.querySelector("#passwordCheck").value;
  
    let isValid = true ; //기본세팅!
    if(email.includes("@") === false) {
      document.querySelector("#error_email").innerText = "이메일이 올바르지 않습니다";
      isValid = false;
    } else {
      document.querySelector("#error_email").innerText = "";
    }
    if(name === "") {
      document.querySelector("#error_name").innerText = "이름이 올바르지 않습니다";
      isValid = false;
    } else {
      document.querySelector("#error_name").innerText = "";
    }
    if(password === "") {
      document.querySelector("#error_password").innerText = "비밀번호를 입력해 주세요";
      isValid = false;
    } else {
      document.querySelector("#error_password").innerText = "";
    }
    if(passwordCheck === "") {
      document.querySelector("#error_password").innerText = "비밀번호가 일치하지 않습니다";
      document.querySelector("#error_passwordCheck").innerText = "비밀번호가 일치하지 않습니다";
      isValid = false;
    }
    if(isValid === true) {
      alert("회원가입을 축하합니다")
    }
  }



  function changePhone1() {
    const phone1 = document.querySelector("#phone1").value;
    if(phone1.length === 3) {
      document.querySelector("#phone2").focus()
    }
  }
  function changePhone2() {
    const phone2 = document.querySelector("#phone2").value;
    if(phone2.length === 4) {
      document.querySelector("#phone3").focus()
    }
  }
  function changePhone3() {
    const phone1 = document.querySelector("#phone1").value;
    const phone2 = document.querySelector("#phone2").value;
    const phone3 = document.querySelector("#phone3").value;
  
    if(phone1.length === 3 &&  phone2.length === 4 && phone3.length === 4) {
      document.querySelector("#admit_send").style = "background-color: #fff; color: #0068ff; cursor: pointer" ;
      document.querySelector("#admit_send").removeAttribute("disabled");
    }
  }







  const form = document.querySelector("#agreement_box"); // 데이터 전송 form
  const checkAll = document.querySelector("#check_all"); // 모두 동의 체크박스
  const checkBoxes = document.querySelectorAll(".agreement_detail_choice"); // 모두 동의 제외 체크박스
  const submitButton = document.querySelector(".btn_joinin"); // 가입 버튼


  const agreements = {
    privacyPolicy: false,
    checkAge : false,
    allowPromotions: false
  };








