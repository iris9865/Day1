$(function() {
  $('.main_gnb').load('/include/navigation.html');
})