import React from 'react'
import './TodoItem.css'

const TodoItem = ({id, isDone, content, createdDate, onUpdate, onDelete}) => {

  return (
    <div className='TodoItem'>
      <div className='check'>
        <input onChange={() => onUpdate(id)} checked={isDone} type='checkbox'/>
      </div>
      <div className='title'>
        {content}
      </div>
      <div className='date'>
        {new Date(createdDate).toLocaleDateString()}
      </div>
      <div className='btn_delete'>
        <button onClick={() => onDelete(id)}>삭제</button>
      </div>
    </div>
  )
}

export default TodoItem
